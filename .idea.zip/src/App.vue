<script setup lang="ts">
// App.vue 作为根组件，包含路由视图
</script>

<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<style scoped>

</style>
